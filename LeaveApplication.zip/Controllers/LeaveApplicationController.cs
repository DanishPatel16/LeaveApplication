﻿using LeaveApplication.Common;
using LeaveApplication.DTO;
using LeaveApplication.LeaveService;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace LeaveApplication.Controllers
{
    [Route("api/")]
    public class LeaveApplicationController : Controller
    {
        private readonly ILeaveService _leaveService;

        public LeaveApplicationController(ILeaveService leaveService)
        {
            _leaveService = leaveService;
        }


        [HttpPost]
        [Route("userLogin")]
        public async Task<IActionResult> UserLogin([FromBody] UserLoginDTO dTO)
        {
            var login = await _leaveService.UserLogin(dTO);
            if (login == null)
                return Ok(new ApiResponse { Success = false, Errors = new List<string>() { "EntityList not found" } });
            return Ok(new ApiResponse() { Success = true, Result = login });
        }

        [HttpGet]
        [Route("getEmployeeDetailsById")]
        public async Task<IActionResult> GetEmployeeDetailsById([FromQuery] IDTO dTO)
        {
            var list = await _leaveService.GetEmployeeDetailsById(dTO);
            if (list == null)
                return Ok(new ApiResponse { Success = false, Errors = new List<string>() { "EntityList not found" } });
            return Ok(new ApiResponse() { Success = true, Result = list });
        }

        [HttpPost]
        [Route("createEmployee")]
        public async Task<IActionResult> CreateEmployee([FromBody] EmployeeDetailsDTO dTO)
        {
            var list = await _leaveService.CreateEmployee(dTO);
            if (list == null)
                return Ok(new ApiResponse { Success = false, Errors = new List<string>() { "EntityList not found" } });
            return Ok(new ApiResponse() { Success = true, Result = list });
        }

        [HttpPost("create-leave")]
        public async Task<IActionResult> CreateLeave([FromBody] LeaveRequestDTO leaveRequestDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            ApiResponse response = await _leaveService.CreateLeave(leaveRequestDTO);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }

        [HttpGet("getLeaveDetails")]
        public async Task<IActionResult> GetLeaveDetails(string employeeCode)
        {
            var leaveDetails = await _leaveService.GetLeaveDetailsByEmployeeCode(employeeCode);

            if (leaveDetails == null || leaveDetails.Count == 0)
            {
                return NotFound(new ApiResponse
                {
                    Success = false,
                    Errors = new List<string> { "No leave details found for this employee." }
                });
            }

            return Ok(new ApiResponse
            {
                Success = true,
                Result = leaveDetails
            });
        }

        [HttpPost("apply-leave")]
        public async Task<IActionResult> ApplyLeave([FromBody] LeaveApplicationDto leaveApplication)
        {
            // Save leave request to database (code omitted)

            // Send email to approver
            var emailSubject = "New Leave Application for Approval";
            var emailBody = $"<p>{leaveApplication.EmployeeName} has applied for leave from {leaveApplication.FromDate} to {leaveApplication.ToDate}. Reason: {leaveApplication.Reason}</p>";
            await _leaveService.SendEmailAsync(leaveApplication.ApproverEmail, emailSubject, emailBody);

            return Ok(new { Message = "Leave application submitted and email sent to approver." });
        }

        [HttpGet("get-manager-email/{employeeId}")]
        public async Task<IActionResult> GetManagerEmail(int employeeId)
        {
            try
            {
                // Call the service to get the manager's email
                var managerEmail = await _leaveService.GetManagerEmailByEmployeeId(employeeId);

                if (string.IsNullOrEmpty(managerEmail))
                {
                    return NotFound("Manager not found.");
                }

                return Ok(new ApiResponse
                {
                    Success = true,
                    Result = managerEmail
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
