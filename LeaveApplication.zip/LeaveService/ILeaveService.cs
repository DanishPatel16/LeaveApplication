﻿using LeaveApplication.Common;
using LeaveApplication.DTO;
using System.Threading.Tasks;

namespace LeaveApplication.LeaveService
{
    public interface ILeaveService
    {
        Task<LoginResponseDTO> UserLogin(UserLoginDTO userLoginDTO);
        Task<List<EmployeeDetailsDTO>> GetEmployeeDetailsById(IDTO iDTO);
        Task<ApiResponse> CreateEmployee(EmployeeDetailsDTO employeeDetailsDTO);
        Task<ApiResponse> CreateLeave(LeaveRequestDTO leaveRequestDTO);
        Task<List<LeaveDetailsDTO>> GetLeaveDetailsByEmployeeCode(string employeeCode);
        Task SendEmailAsync(string toEmail, string subject, string body);
        Task<string> GetManagerEmailByEmployeeId(int employeeId);

    }
}
