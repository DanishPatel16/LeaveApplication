﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using LeaveApplication.Common;
using LeaveApplication.DTO;
using LeaveApplication.LeaveRepository;

namespace LeaveApplication.LeaveService
{
    public class LeaveService : ILeaveService
    {
        private readonly ILeaveRepository _leaveRepository;

        public LeaveService(ILeaveRepository leaveRepository)
        {
            _leaveRepository = leaveRepository;
        }

        public async Task<LoginResponseDTO> UserLogin(UserLoginDTO userLoginDTO)
        {
            return await _leaveRepository.UserLogin(userLoginDTO);
        }

        public async Task<List<EmployeeDetailsDTO>> GetEmployeeDetailsById(IDTO iDTO)
        {
            return await _leaveRepository.GetEmployeeDetailsById(iDTO);
        }

        public async Task<ApiResponse> CreateEmployee(EmployeeDetailsDTO employeeDetailsDTO)
        {
            var employeeDetailsResponseDTO = new List<EmployeeDetailsResponseDTO>();

            try
            {
                int id = await _leaveRepository.IsRecordExist(employeeDetailsDTO);

                if (id == 0)
                {
                    var employeeId = await _leaveRepository.CreateEmployee(employeeDetailsDTO);
                    if (employeeId > 0)
                    {
                        employeeDetailsResponseDTO.Add(new EmployeeDetailsResponseDTO
                        {
                            EmployeeId = employeeId,
                            EmployeeCode = employeeDetailsDTO.EmployeeCode,
                            FirstName = employeeDetailsDTO.FirstName,
                            LastName = employeeDetailsDTO.LastName,
                            Email = employeeDetailsDTO.Email,
                            Status = "Record Inserted Successfully...!"
                        });
                    }

                    return new ApiResponse
                    {
                        Success = true,
                        Result = employeeDetailsResponseDTO
                    };
                }
                else
                {
                    employeeDetailsResponseDTO.Add(new EmployeeDetailsResponseDTO
                    {
                        EmployeeId = id,
                        EmployeeCode = employeeDetailsDTO.EmployeeCode,
                        FirstName = employeeDetailsDTO.FirstName,
                        LastName = employeeDetailsDTO.LastName,
                        Email = employeeDetailsDTO.Email,
                        Status = "Record Already Exists...!"
                    });
                }

                return new ApiResponse
                {
                    Success = false,
                    Result = employeeDetailsResponseDTO
                };
            }
            catch (Exception ex)
            {
                return new ApiResponse
                {
                    Success = false,
                    Errors = new List<string> { $"An error occurred: {ex.Message}" },
                    Result = null
                };
            }
        }

        public async Task<ApiResponse> CreateLeave(LeaveRequestDTO leaveRequestDTO)
        {
            try
            {
                int leaveId = await _leaveRepository.CreateLeave(leaveRequestDTO);

                if (leaveId > 0)
                {
                    return new ApiResponse
                    {
                        Success = true,
                        Result = new { LeaveID = leaveId, Status = "Leave details inserted successfully!" }
                    };
                }
                else
                {
                    return new ApiResponse
                    {
                        Success = false,
                        Errors = new List<string> { "Failed to insert leave details." }
                    };
                }
            }
            catch (Exception ex)
            {
                return new ApiResponse
                {
                    Success = false,
                    Errors = new List<string> { $"An error occurred: {ex.Message}" }
                };
            }
        }

        public async Task<List<LeaveDetailsDTO>> GetLeaveDetailsByEmployeeCode(string employeeCode)
        {
            return await _leaveRepository.GetLeaveDetailsByEmployeeCode(employeeCode);
        }
        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            await _leaveRepository.SendEmailAsync(toEmail, subject, body);
        }

        public async Task<string> GetManagerEmailByEmployeeId(int employeeId)
        {
            // Call the repository to get the manager's email.
            var managerEmail = await _leaveRepository.GetManagerEmailByEmployeeId(employeeId);

            if (string.IsNullOrEmpty(managerEmail))
            {
                throw new Exception("Manager email not found.");
            }

            return managerEmail;
        }

    }
}
