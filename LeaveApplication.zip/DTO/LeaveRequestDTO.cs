﻿using System;

namespace LeaveApplication.DTO
{
    public class LeaveRequestDTO
    {

         
        public string employeeCode { get; set; }  
        public string employeeName { get; set; }   
                
        public string Approver { get; set; }       
        public string LeaveType { get; set; }      
        public DateTime FromDate { get; set; }     
        public string dayTypeFrom { get; set; }    
        public DateTime ToDate { get; set; }       
        public string dayTypeTo { get; set; }      
        public string Reason { get; set; }         
               
        public DateTime CreatedAt { get; set; }    
        public DateTime UpdatedAt { get; set; }
    }
}
