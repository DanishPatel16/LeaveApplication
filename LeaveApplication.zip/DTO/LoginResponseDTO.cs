﻿namespace LeaveApplication.DTO
{
    public class LoginResponseDTO
    {   
        public int EmployeeId { get; set; }
        public string EmployeeCode { get; set; }
    }
}
