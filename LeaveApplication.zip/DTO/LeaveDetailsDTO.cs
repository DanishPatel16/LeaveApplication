﻿namespace LeaveApplication.DTO
{
    public class LeaveDetailsDTO
    {
        public string LeaveType { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Reason { get; set; }
        public string Approver { get; set; }
    }
}
