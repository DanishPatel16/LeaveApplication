﻿namespace LeaveApplication.DTO
{
    public class IDTO
    {
        public int ID {  get; set; }
       
    }
}
