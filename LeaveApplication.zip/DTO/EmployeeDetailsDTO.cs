﻿namespace LeaveApplication.DTO
{
    public class EmployeeDetailsDTO
    {
        public string EmployeeCode { get; set; }
        public string FirstName { get; set; }
        public string? MiddelName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string? Department { get; set; }
        public string? Position { get; set; }
        public string? Role { get; set; }
        public string? ManagerId { get; set; }
        public string? PancardNo { get; set; }
        public string? AdharcardNo { get; set; }
        public string? CurrentAddress { get; set; }
        public string? PermanentAddress { get; set; }
        public string? BloodGroup { get; set; }
        public DateTime? JoiningDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string Password { get; set; }
    }
}
