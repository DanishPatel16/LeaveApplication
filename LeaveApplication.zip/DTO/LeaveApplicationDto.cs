﻿namespace LeaveApplication.DTO
{
    public class LeaveApplicationDto
    {

        public int EmployeeId { get; set; }            
        public string EmployeeName { get; set; }         
        public string ApproverEmail { get; set; }        
        public string LeaveType { get; set; }             
        public DateTime FromDate { get; set; }            
        public DateTime ToDate { get; set; }             
        public string DayTypeFrom { get; set; }          
        public string DayTypeTo { get; set; }          
        public string Reason { get; set; }                
        public DateTime CreatedAt { get; set; }
    }
}
