﻿using LeaveApplication.DTO;
using Dapper;
using System.Data.Common;
using System.Data;
using LeaveApplication.Common;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Net.Mail;
namespace LeaveApplication.LeaveRepository
{
    public class LeaveRepository : DapperContext, ILeaveRepository
    {
        private readonly IConfiguration _configuration;
        public LeaveRepository(IConfiguration configuration) : base(configuration)
        {
            _configuration = configuration;
        }
        public async Task<LoginResponseDTO> UserLogin(UserLoginDTO userLoginDTO)
        {
            var hashedPassword = PasswordUtility.HashPassword(userLoginDTO.Password);
            try
            {
                var query = "SELECT DISTINCT EmployeeId, EmployeeCode FROM Users WHERE Email = @Email AND Password = @Password";
                using (var dbConnection = CreateConnecttion())
                {
                    return await dbConnection.QueryFirstOrDefaultAsync<LoginResponseDTO>(query, new { Email = userLoginDTO.Email, Password = hashedPassword });
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<EmployeeDetailsDTO>> GetEmployeeDetailsById(IDTO iDTO)
        {
            try
            {
                var query = "SELECT DISTINCT * FROM Users WHERE EmployeeId =@EmployeeId";
                using (var dbConnection = CreateConnecttion())
                {

                    return (await dbConnection.QueryAsync<EmployeeDetailsDTO>(query, new { @EmployeeId = iDTO.ID })).ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> IsRecordExist(EmployeeDetailsDTO dTO)
        {
            try
            {
                var query = "SELECT DISTINCT EmployeeId FROM Users WHERE Email = @Email";
                using (var dbConnection = CreateConnecttion())
                {
                    int result = await dbConnection.ExecuteScalarAsync<int>(query, new { Email = dTO.Email });
                    return result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> CreateEmployee(EmployeeDetailsDTO dTO)
        {
            var hashedPassword = PasswordUtility.HashPassword(dTO.Password);

            try
            {
                var query = "INSERT INTO Users ( EmployeeCode, FirstName, MiddelName, LastName, Email, ContactNo, Department, Position, Role, ManagerId, PancardNo, AdharcardNo, CurrentAddress, PermanentAddress, BloodGroup, JoiningDate, ReleaseDate, Password)" +
                            "Values( @EmployeeCode, @FirstName, @MiddelName, @LastName, @Email, @ContactNo, @Department, @Position, @Role, @ManagerId, @PancardNo, @AdharcardNo, @CurrentAddress, @PermanentAddress, @BloodGroup, @JoiningDate, @ReleaseDate, @Password); SELECT SCOPE_IDENTITY();";
                using (var dbConnection = CreateConnecttion())
                {

                    int result = await dbConnection.ExecuteScalarAsync<int>(query, new
                    {
                        EmployeeCode = dTO.EmployeeCode,
                        @FirstName = dTO.FirstName,
                        @MiddelName = dTO.MiddelName,
                        @LastName = dTO.LastName,
                        @Email = dTO.Email,
                        @ContactNo = dTO.ContactNo,
                        @Department = dTO.Department,
                        @Position = dTO.Position,
                        @Role = dTO.Role,
                        @ManagerId = dTO.ManagerId,
                        @PancardNo = dTO.PancardNo,
                        @AdharcardNo = dTO.AdharcardNo,
                        @CurrentAddress = dTO.CurrentAddress,
                        @PermanentAddress = dTO.PermanentAddress,
                        @BloodGroup = dTO.BloodGroup,
                        @JoiningDate = dTO.JoiningDate,
                        @ReleaseDate = dTO.ReleaseDate,
                        @Password = hashedPassword
                    });
                    return result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> CreateLeave(LeaveRequestDTO leaveRequestDTO)
        {
            try
            {
                var query = @"
            INSERT INTO LeaveDetails (employeeCode, employeeName,  LeaveType, FromDate, dayTypeFrom, ToDate, dayTypeTo, Reason, Approver,  CreatedAt, UpdatedAt)
            VALUES (@employeeCode, @employeeName,  @LeaveType, @FromDate, @dayTypeFrom, @ToDate, @dayTypeTo, @Reason, @Approver,  @CreatedAt, @UpdatedAt);
            SELECT SCOPE_IDENTITY();";

                using (var dbConnection = CreateConnecttion())
                {
                    var parameters = new
                    {
                        leaveRequestDTO.employeeCode,
                        leaveRequestDTO.employeeName,
                     
                        leaveRequestDTO.LeaveType,
                        leaveRequestDTO.FromDate,
                        leaveRequestDTO.dayTypeFrom,
                        leaveRequestDTO.ToDate,
                        leaveRequestDTO.dayTypeTo,
                        leaveRequestDTO.Reason,
                        leaveRequestDTO.Approver,
                        
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };


                    return await dbConnection.ExecuteScalarAsync<int>(query, parameters);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error inserting leave details", ex);
            }
        }
        public async Task<List<LeaveDetailsDTO>> GetLeaveDetailsByEmployeeCode(string employeeCode)
        {
            try
            {
                var query = @"
                    SELECT LeaveType, FromDate, ToDate, Reason, Approver 
                    FROM LeaveDetails 
                    WHERE EmployeeCode = @EmployeeCode";

                using (var dbConnection = CreateConnecttion())
                {
                    return (await dbConnection.QueryAsync<LeaveDetailsDTO>(query, new { EmployeeCode = employeeCode })).AsList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching leave details", ex);
            }
        }

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            try
            {
                var smtpClient = new SmtpClient(_configuration["SmtpSettings:Server"])
                {
                    Port = int.Parse(_configuration["SmtpSettings:Port"]),
                    Credentials = new System.Net.NetworkCredential(
                        _configuration["SmtpSettings:Username"],
                        _configuration["SmtpSettings:Password"]),
                    EnableSsl = true,
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_configuration["SmtpSettings:SenderEmail"], _configuration["SmtpSettings:SenderName"]),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true,
                };

                mailMessage.To.Add(toEmail);

                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (SmtpException smtpEx)
            {
               
                throw new Exception("Error sending email due to SMTP issue", smtpEx);
            }
            catch (Exception ex)
            {
               
                throw new Exception("An error occurred while sending email", ex);
            }
        }

        public async Task<string> GetManagerEmailByEmployeeId(int employeeId)
        {
            try
            {
                // Query to get the employee details
                var query = "SELECT ManagerId FROM Users WHERE EmployeeId = @EmployeeId";

                using (var dbConnection = CreateConnecttion()) // Make sure CreateConnecttion() is a valid method that creates the database connection
                {
                    // Get the managerId for the given employee
                    var managerId = await dbConnection.ExecuteScalarAsync<int?>(query, new { EmployeeId = employeeId });

                    // If no manager is found, return null
                    if (managerId == null)
                    {
                        return null;
                    }

                    // Query to get the manager's email based on the managerId
                    var managerEmailQuery = "SELECT Email FROM Users WHERE EmployeeId = @ManagerId";
                    var managerEmail = await dbConnection.ExecuteScalarAsync<string>(managerEmailQuery, new { ManagerId = managerId });

                    return managerEmail; // Return the manager's email or null if not found
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error retrieving manager email", ex);
            }
        }

    }
}

