﻿using LeaveApplication.DTO;

namespace LeaveApplication.LeaveRepository
{
    public interface ILeaveRepository
    {
        Task<LoginResponseDTO> UserLogin(UserLoginDTO userLoginDTO);
        Task<List<EmployeeDetailsDTO>> GetEmployeeDetailsById(IDTO iDTO);
        Task<int> IsRecordExist(EmployeeDetailsDTO dTO);
        Task<int> CreateEmployee(EmployeeDetailsDTO employeeDetailsDTO);
        Task<int> CreateLeave(LeaveRequestDTO leaveRequestDTO);
        Task<List<LeaveDetailsDTO>> GetLeaveDetailsByEmployeeCode(string employeeCode);
        Task SendEmailAsync(string toEmail, string subject, string body);
        Task<string> GetManagerEmailByEmployeeId(int employeeId);


    }
}
